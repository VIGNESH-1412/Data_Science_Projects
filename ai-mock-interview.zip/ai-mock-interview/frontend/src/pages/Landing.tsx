import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <section className="hero">
      <div>
        <h1>Practice the interview before it counts.</h1>
        <p className="lead">Answer technical, behavioral and HR questions by typing or speaking. Each answer is scored against a rubric for the concepts you covered, how relevant you were and how clearly you said it, and you get a plan built from the gaps that keep showing up.</p>
        <p><Link className="btn" to="/register">Create a free account</Link> <Link className="btn ghost" to="/login">Log in</Link></p>
      </div>
      <aside className="sample" aria-label="Sample feedback">
        <p className="muted">Question</p>
        <p>Explain the difference between INNER JOIN and LEFT JOIN.</p>
        <p className="muted">Concepts found in your answer</p>
        <ul className="ticks">
          <li className="ok">Inner join returns only matching rows</li>
          <li className="ok">Left join keeps all left-table rows</li>
          <li className="miss">Unmatched right side becomes NULL</li>
        </ul>
        <p className="muted">Next: “What values appear for right-table columns when a LEFT JOIN finds no match?”</p>
      </aside>
    </section>
  );
}
