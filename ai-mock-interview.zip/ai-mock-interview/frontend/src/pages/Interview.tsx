import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../api";

export default function Interview() {
  const { id } = useParams();
  const nav = useNavigate();
  const [cfg, setCfg] = useState<any>(null);
  const [q, setQ] = useState<any>(null);
  const [text, setText] = useState("");
  const [fb, setFb] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [consent, setConsent] = useState(false);
  const [rec, setRec] = useState(false);
  const [voice, setVoice] = useState<any>(null); // {original, segments, conf, duration}
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const recStart = useRef(0);
  const shownAt = useRef(Date.now());

  const showQuestion = (res: any) => {
    if (res.done) { finish(); return; }
    setQ(res.question); setText(""); setFb(null); setVoice(null); setElapsed(0); shownAt.current = Date.now();
  };
  const finish = async () => { await api(`/interviews/${id}/complete`, { method: "POST" }); nav(`/results/${id}`); };

  useEffect(() => {
    (async () => {
      try {
        const s = await api(`/interviews/${id}`);
        setCfg(s.config);
        if (s.status === "completed") return nav(`/results/${id}`);
        if (s.status === "created") return showQuestion(await api(`/interviews/${id}/start`, { method: "POST" }));
        const open = s.questions.find((x: any) => !x.answered);
        open ? showQuestion({ question: open }) : showQuestion(await api(`/interviews/${id}/next-question`, { method: "POST" }));
      } catch (e: any) { setErr(e.message); }
    })();
  }, [id]);

  useEffect(() => { const t = setInterval(() => setElapsed(Math.floor((Date.now() - shownAt.current) / 1000)), 1000); return () => clearInterval(t); }, [q]);

  const speak = () => { const u = new SpeechSynthesisUtterance(q.text); speechSynthesis.cancel(); speechSynthesis.speak(u); };

  const startRec = async () => {
    setErr("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunks.current = [];
      mr.ondataavailable = (e) => chunks.current.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const duration = (Date.now() - recStart.current) / 1000;
        const form = new FormData();
        form.append("consent", "true");
        form.append("audio", new Blob(chunks.current, { type: "audio/webm" }), "answer.webm");
        setBusy(true);
        try {
          const r = await api(`/interviews/${id}/transcribe`, { form });
          setText(r.text); setVoice({ original: r.text, segments: r.segments, conf: r.asr_confidence, duration });
        } catch (e: any) { setErr(e.message + " You can type your answer instead."); }
        setBusy(false);
      };
      recorder.current = mr; recStart.current = Date.now(); mr.start(); setRec(true);
    } catch { setErr("Microphone access was denied or is unavailable. You can type your answer instead."); }
  };
  const stopRec = () => { recorder.current?.stop(); setRec(false); };

  const submit = async (skipped = false) => {
    setBusy(true); setErr("");
    try {
      const body: any = { question_id: q.id, text: skipped ? "" : text, skipped, duration_sec: voice?.duration ?? (Date.now() - shownAt.current) / 1000 };
      if (voice) Object.assign(body, { via_voice: true, original_transcript: voice.original, speech_segments: voice.segments, asr_confidence: voice.conf });
      setFb(await api(`/interviews/${id}/answers`, { body }));
    } catch (e: any) { setErr(e.message); }
    setBusy(false);
  };
  const next = async () => { setBusy(true); try { showQuestion(await api(`/interviews/${id}/next-question`, { method: "POST" })); } catch (e: any) { setErr(e.message); } setBusy(false); };

  if (err && !q) return <p className="err" role="alert">{err}</p>;
  if (!q) return <p className="muted">Preparing your first question…</p>;
  const ev = fb?.evaluation;
  return (
    <div className="card">
      <p className="muted">{q.competency} · {q.difficulty}{q.is_followup ? " · follow-up" : ""} · suggested {Math.round(q.time_limit_sec / 60 * 10) / 10} min · elapsed {elapsed}s</p>
      <h2>{q.text}</h2>
      <button className="link" onClick={speak}>Read the question aloud</button>
      {!fb && (
        <>
          {cfg?.mode === "voice" && (
            <div className="voice">
              <label><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} /> I consent to recording my voice for transcription. The audio is deleted right after transcription; only the transcript is kept.</label>
              {!rec ? <button className="btn ghost" disabled={!consent || busy} onClick={startRec}>Record answer</button> : <button className="btn danger" onClick={stopRec}>Stop recording</button>}
              {busy && <span className="muted"> Transcribing…</span>}
              {voice && <p className="muted">Check the transcript below and correct any recognition mistakes before you submit.</p>}
            </div>
          )}
          <label>Your answer<textarea rows={8} value={text} onChange={(e) => setText(e.target.value)} placeholder="Type your answer here…" /></label>
          {err && <p className="err" role="alert">{err}</p>}
          <button className="btn" disabled={busy || !text.trim()} onClick={() => submit(false)}>Submit answer</button>{" "}
          <button className="link" disabled={busy} onClick={() => submit(true)}>Skip question</button>
        </>
      )}
      {ev && (
        <div className="fb">
          <h3>Score: {ev.overall} / 100 <span className="muted">(estimate)</span></h3>
          <p className="muted">{Object.entries(ev.components).map(([k, v]: any) => `${k.replace(/_/g, " ")} ${v}`).join(" · ")}</p>
          {ev.feedback.caution && <p className="warn">{ev.feedback.caution}</p>}
          <p><b>Did well:</b> {ev.feedback.did_well.join(" ")}</p>
          {ev.feedback.missing.length > 0 && <p><b>Missing:</b> {ev.feedback.missing.join("; ")}</p>}
          {ev.feedback.errors.length > 0 && <p className="err"><b>Possible errors:</b> {ev.feedback.errors.join(" ")}</p>}
          <p><b>Structure to use:</b> {ev.feedback.structure_tip}</p>
          <details><summary>Stronger example answer</summary><p>{ev.feedback.stronger_answer}</p></details>
          <p><b>Practice next:</b> {ev.feedback.practice_question}</p>
          <button className="btn" disabled={busy} onClick={next}>Next question</button>{" "}
          <button className="link" onClick={finish}>End interview now</button>
        </div>
      )}
    </div>
  );
}
