import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import { api } from "../api";

const schema = z.object({
  role: z.string().min(2, "Enter a role"),
  level: z.enum(["fresher", "junior", "intermediate", "senior"]),
  interview_type: z.enum(["technical", "hr", "behavioral", "managerial", "mixed"]),
  difficulty: z.enum(["easy", "medium", "hard"]),
  num_questions: z.coerce.number().int().min(3).max(20),
  duration_minutes: z.coerce.number().int().min(5).max(90),
  skills: z.string().optional(),
  job_description: z.string().optional(),
  mode: z.enum(["text", "voice"]),
  resume_id: z.string().optional(),
});

export default function Configure() {
  const nav = useNavigate();
  const [resumes, setResumes] = useState<any[]>([]);
  const [plan, setPlan] = useState<any>(null);
  const [err, setErr] = useState("");
  const { register, handleSubmit, formState: { errors } } = useForm<any>({
    resolver: zodResolver(schema),
    defaultValues: { role: "Data Analyst", level: "fresher", interview_type: "mixed", difficulty: "medium", num_questions: 6, duration_minutes: 30, mode: "text" },
  });
  useEffect(() => { api("/resumes").then(setResumes); }, []);
  const submit = async (v: any) => {
    setErr("");
    try {
      const body = { ...v, skills: (v.skills || "").split(",").map((s: string) => s.trim()).filter(Boolean), resume_id: v.resume_id || null };
      setPlan(await api("/interviews", { body }));
    } catch (e: any) { setErr(e.message); }
  };
  if (plan) {
    return (
      <section className="card narrow">
        <h2>Your interview plan</h2>
        <ol>{plan.plan.map((p: any) => <li key={p.slot}>{p.type} question</li>)}</ol>
        <p className="muted">Follow-ups and difficulty adapt to your answers. Specific questions are chosen as you go.</p>
        <button className="btn" onClick={() => nav(`/interview/${plan.id}`)}>Start interview</button>{" "}
        <button className="btn ghost" onClick={() => setPlan(null)}>Change settings</button>
      </section>
    );
  }
  const sel = (name: string, opts: string[]) => <select {...register(name)}>{opts.map((o) => <option key={o}>{o}</option>)}</select>;
  return (
    <form className="card narrow" onSubmit={handleSubmit(submit)} noValidate>
      <h2>Configure interview</h2>
      <label>Job role<input {...register("role")} /></label>
      {errors.role && <p className="err">{errors.role.message as string}</p>}
      <div className="row">
        <label>Experience level{sel("level", ["fresher", "junior", "intermediate", "senior"])}</label>
        <label>Interview type{sel("interview_type", ["mixed", "technical", "hr", "behavioral", "managerial"])}</label>
        <label>Difficulty{sel("difficulty", ["easy", "medium", "hard"])}</label>
      </div>
      <div className="row">
        <label>Questions<input type="number" {...register("num_questions")} /></label>
        <label>Time limit (min)<input type="number" {...register("duration_minutes")} /></label>
        <label>Answer by{sel("mode", ["text", "voice"])}</label>
      </div>
      <label>Skills to focus on (comma separated)<input placeholder="sql, python, power bi" {...register("skills")} /></label>
      <label>Resume (adds project questions)
        <select {...register("resume_id")}><option value="">None</option>{resumes.map((r) => <option key={r.id} value={r.id}>{r.filename}</option>)}</select>
      </label>
      <label>Job description (optional)<textarea rows={3} {...register("job_description")} /></label>
      {err && <p className="err" role="alert">{err}</p>}
      <button className="btn">Generate plan</button>
    </form>
  );
}
