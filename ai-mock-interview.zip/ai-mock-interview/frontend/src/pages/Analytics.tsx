import { useEffect, useState } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api";

const shade = (v: number) => `hsl(${Math.round((v / 100) * 120)}, 55%, ${v < 50 ? 82 : 78}%)`;

export default function Analytics() {
  const [perf, setPerf] = useState<any>(null);
  const [gaps, setGaps] = useState<any>(null);
  useEffect(() => { api("/analytics/performance").then(setPerf); api("/analytics/skill-gaps").then(setGaps); }, []);
  if (!perf || !gaps) return <p className="muted">Loading…</p>;
  const data = perf.sessions.map((s: any, i: number) => ({ n: `#${i + 1}`, overall: s.overall, ...s.dimensions }));
  return (
    <>
      <h2>Progress</h2>
      <section className="card">
        <h3>Sessions over time</h3>
        {data.length ? <ResponsiveContainer width="100%" height={260}><LineChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="n" /><YAxis domain={[0, 100]} /><Tooltip /><Legend />
          <Line dataKey="overall" stroke="#12263a" strokeWidth={2} /><Line dataKey="completeness" stroke="#1d6f8c" /><Line dataKey="communication" stroke="#b7791f" /><Line dataKey="semantic_relevance" stroke="#2f7d4f" /></LineChart></ResponsiveContainer>
          : <p className="muted">No completed interviews yet.</p>}
        {perf.comparison && <p>Previous {perf.comparison.previous} → current {perf.comparison.current} ({perf.comparison.change >= 0 ? "+" : ""}{perf.comparison.change}). Small changes may be noise.</p>}
      </section>
      <section className="card">
        <h3>Skill-gap heatmap</h3>
        {!gaps.heatmap.length && <p className="muted">Answer a few questions to see which competencies need work.</p>}
        <div className="heat">{gaps.heatmap.map((h: any) => <div key={h.competency} style={{ background: shade(h.average) }}><b>{h.average}</b><span>{h.competency}</span><small>{h.attempts} answers</small></div>)}</div>
      </section>
      <section className="card">
        <h3>Suggested next practice</h3>
        {gaps.learning_plan.length ? <ul>{gaps.learning_plan.map((p: any) => <li key={p.competency}><b>{p.competency}</b> ({p.priority} priority, avg {p.average}): {p.action}</li>)}</ul>
          : <p className="muted">No repeated weak areas yet. Plans appear after a competency scores low across multiple answers.</p>}
      </section>
    </>
  );
}
