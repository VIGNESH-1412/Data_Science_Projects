import { useEffect, useState } from "react";
import { api } from "../api";

export default function ResumePage() {
  const [list, setList] = useState<any[]>([]);
  const [err, setErr] = useState("");
  const [jd, setJd] = useState("");
  const [compat, setCompat] = useState<Record<string, any>>({});
  const load = () => api("/resumes").then(setList);
  useEffect(() => { load(); }, []);
  const upload = async (e: any) => {
    const f = e.target.files?.[0]; if (!f) return;
    setErr("");
    const form = new FormData(); form.append("file", f);
    try { await api("/resumes", { form }); load(); } catch (x: any) { setErr(x.message); }
    e.target.value = "";
  };
  const del = async (id: string) => { if (confirm("Delete this resume and its stored file?")) { await api(`/resumes/${id}`, { method: "DELETE" }); load(); } };
  const check = async (id: string) => setCompat({ ...compat, [id]: await api(`/resumes/${id}/compatibility`, { body: { job_description: jd } }) });
  return (
    <>
      <h2>Resume</h2>
      <section className="card">
        <label>Upload a PDF or DOCX (max 5 MB)<input type="file" accept=".pdf,.docx" onChange={upload} /></label>
        {err && <p className="err" role="alert">{err}</p>}
        <p className="muted">Skills and sections are extracted automatically and are not verified. You can delete the file at any time.</p>
        <label>Job description (optional, for a compatibility check)<textarea rows={4} value={jd} onChange={(e) => setJd(e.target.value)} /></label>
      </section>
      {list.map((r) => (
        <section className="card" key={r.id}>
          <h3>{r.filename}</h3>
          <p><b>Skills found:</b> {r.analysis.skills?.join(", ") || "none"}</p>
          <p className="muted">Sections detected: {r.analysis.sections_detected?.join(", ") || "none"}</p>
          <p><b>Suggested interview topics:</b> {r.analysis.suggested_topics?.join(", ")}</p>
          {compat[r.id] && (
            <p>Compatibility: <b>{compat[r.id].score ?? "n/a"}{compat[r.id].score != null && "%"}</b>. Matched: {compat[r.id].matched.join(", ") || "–"}. Missing: {compat[r.id].missing.join(", ") || "–"}. <span className="muted">{compat[r.id].note}</span></p>
          )}
          <button className="btn ghost" disabled={!jd.trim()} onClick={() => check(r.id)}>Compare with job description</button>{" "}
          <button className="link danger" onClick={() => del(r.id)}>Delete resume</button>
        </section>
      ))}
    </>
  );
}
