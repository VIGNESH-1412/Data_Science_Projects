import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api";

export default function Results() {
  const { id } = useParams();
  const [r, setR] = useState<any>(null);
  const [edit, setEdit] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  const load = () => api(`/interviews/${id}/results`).then(setR);
  useEffect(() => { load(); }, [id]);
  if (!r) return <p className="muted">Loading…</p>;
  const s = r.summary;
  const radar = Object.entries(s.competencies || {}).map(([k, v]) => ({ competency: k, score: v }));
  const dims = Object.entries(s.dimensions || {}).map(([k, v]) => ({ name: k.replace(/_/g, " "), score: v }));
  const pdf = async () => { const rep = await api(`/interviews/${id}/report`, { method: "POST" }); window.open(rep.download, "_blank"); };
  const reeval = async (aid: string) => { await api(`/answers/${aid}/evaluate`, { body: { text: edit[aid] } }); setEdit({ ...edit, [aid]: undefined as any }); load(); };
  const flag = async (aid: string, kind: string) => { await api(`/answers/${aid}/feedback`, { body: { kind, comment: "" } }); setMsg("Thanks, your feedback was recorded."); };
  return (
    <>
      <h2>Results: {r.config.role}</h2>
      <p className="muted">{r.disclaimer}</p>
      <div className="grid2">
        <section className="card"><h3>Overall</h3><p className="big">{s.overall}<span className="muted"> / 100</span></p>
          <p>{s.answered} answered · {s.skipped} skipped · {s.unanswered_questions} unanswered{s.duration_sec ? ` · ${Math.round(s.duration_sec / 60)} min` : ""}</p>
          <button className="btn" onClick={pdf}>Download PDF report</button> <button className="btn ghost" onClick={() => window.print()}>Print view</button></section>
        <section className="card"><h3>Score dimensions</h3>
          <ResponsiveContainer width="100%" height={200}><BarChart data={dims} layout="vertical"><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" domain={[0, 100]} /><YAxis type="category" dataKey="name" width={130} /><Tooltip /><Bar dataKey="score" fill="#1d6f8c" /></BarChart></ResponsiveContainer></section>
      </div>
      {radar.length >= 3 && <section className="card"><h3>Competencies</h3>
        <ResponsiveContainer width="100%" height={280}><RadarChart data={radar}><PolarGrid /><PolarAngleAxis dataKey="competency" /><PolarRadiusAxis domain={[0, 100]} /><Radar dataKey="score" stroke="#1d6f8c" fill="#1d6f8c" fillOpacity={0.35} /></RadarChart></ResponsiveContainer></section>}
      {msg && <p className="ok-text" role="status">{msg}</p>}
      <h3>Question breakdown</h3>
      {r.items.map((it: any, i: number) => (
        <details className="card" key={it.id} open={i === 0}>
          <summary><b>Q{i + 1}.</b> {it.text} <span className="chip">{it.evaluation.overall}</span></summary>
          <p className="muted">{it.competency} · {it.difficulty} · {Object.entries(it.evaluation.components).map(([k, v]: any) => `${k.replace(/_/g, " ")} ${v}`).join(" · ")}</p>
          <p><b>Your answer:</b> {it.answer || "(skipped)"}</p>
          {it.speech_metrics?.words_per_minute && <p className="muted">Speech: {it.speech_metrics.words_per_minute} words/min · {it.speech_metrics.filler_count} filler words · {it.speech_metrics.long_pauses_over_2s ?? 0} long pauses. Descriptive only; not scored as confidence or ability.</p>}
          <details><summary>Why this score?</summary>
            <ul>{it.evaluation.details.coverage.map((c: any) => <li key={c.concept} className={c.score > 0 ? "ok" : "miss"}>{c.concept} ({c.method}){c.evidence && <em> — “{c.evidence}”</em>}</li>)}</ul>
            {it.evaluation.details.flags.length > 0 && <p className="muted">Flags: {it.evaluation.details.flags.join(", ")}</p>}
            <p className="muted">Model {it.evaluation.model_version} · {it.evaluation.rubric_version}</p>
          </details>
          <p><b>Missing:</b> {it.evaluation.feedback.missing.join("; ") || "nothing major"}</p>
          <p><b>Stronger answer:</b> {it.evaluation.feedback.stronger_answer}</p>
          <label>Fix a transcription mistake and re-score<textarea rows={3} value={edit[it.answer_id] ?? it.answer} onChange={(e) => setEdit({ ...edit, [it.answer_id]: e.target.value })} /></label>
          <button className="btn ghost" onClick={() => reeval(it.answer_id)} disabled={!edit[it.answer_id]}>Re-score</button>{" "}
          <button className="link" onClick={() => flag(it.answer_id, "unfair_score")}>Flag as unfair</button>
        </details>
      ))}
      {r.unanswered.length > 0 && <section className="card"><h3>Unanswered</h3><ul>{r.unanswered.map((u: any) => <li key={u.id}>{u.text}</li>)}</ul></section>}
    </>
  );
}
