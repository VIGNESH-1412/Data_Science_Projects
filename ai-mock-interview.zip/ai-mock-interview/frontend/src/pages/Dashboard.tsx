import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api";
import { useAuth } from "../App";

export default function Dashboard() {
  const { user } = useAuth();
  const [list, setList] = useState<any>({ items: [], total: 0 });
  const [perf, setPerf] = useState<any>({ sessions: [], comparison: null });
  useEffect(() => { api("/interviews?limit=10").then(setList); api("/analytics/performance").then(setPerf); }, []);
  const remove = async (id: string) => { if (confirm("Delete this interview and its answers?")) { await api(`/interviews/${id}`, { method: "DELETE" }); setList(await api("/interviews?limit=10")); } };
  const data = perf.sessions.map((s: any, i: number) => ({ n: `#${i + 1}`, overall: s.overall }));
  return (
    <>
      <h2>Welcome, {user?.full_name.split(" ")[0]}</h2>
      <div className="grid2">
        <section className="card">
          <h3>Score trend</h3>
          {data.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="n" /><YAxis domain={[0, 100]} /><Tooltip /><Line dataKey="overall" stroke="#1d6f8c" strokeWidth={2} /></LineChart>
            </ResponsiveContainer>
          ) : <p className="muted">Complete an interview to see your trend.</p>}
          {perf.comparison && <p>Last session vs. previous: <b>{perf.comparison.change >= 0 ? "+" : ""}{perf.comparison.change}</b> points (estimate).</p>}
        </section>
        <section className="card">
          <h3>Start practising</h3>
          <p>Pick a role, difficulty and format. A plan is generated before you begin.</p>
          <Link className="btn" to="/interview/new">Configure an interview</Link>
        </section>
      </div>
      <section className="card">
        <h3>Your interviews ({list.total})</h3>
        {!list.items.length && <p className="muted">No interviews yet. Configure one to get started.</p>}
        <table className="tbl"><tbody>
          {list.items.map((i: any) => (
            <tr key={i.id}>
              <td>{new Date(i.created_at).toLocaleDateString()}</td><td>{i.role}</td><td>{i.type}</td><td>{i.status}</td>
              <td>{i.overall ?? "–"}</td>
              <td>{i.status === "completed" ? <Link to={`/results/${i.id}`}>View results</Link> : <Link to={`/interview/${i.id}`}>Continue</Link>}</td>
              <td><button className="link danger" onClick={() => remove(i.id)}>Delete</button></td>
            </tr>
          ))}
        </tbody></table>
      </section>
    </>
  );
}
