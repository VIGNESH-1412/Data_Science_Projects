import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../App";

const loginSchema = z.object({ email: z.string().email("Enter a valid email"), password: z.string().min(1, "Enter your password") });
const regSchema = loginSchema.extend({ full_name: z.string().min(1, "Enter your name"), password: z.string().min(8, "Use at least 8 characters") });

function useSubmit(path: string) {
  const { setUser } = useAuth();
  const nav = useNavigate();
  const [err, setErr] = useState("");
  const submit = async (body: any) => {
    setErr("");
    try { setUser(await api(path, { body })); nav("/dashboard"); } catch (e: any) { setErr(e.message); }
  };
  return { err, submit };
}

export function Login() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(loginSchema) });
  const { err, submit } = useSubmit("/auth/login");
  return (
    <form className="card narrow" onSubmit={handleSubmit(submit)} noValidate>
      <h2>Log in</h2>
      <label>Email<input type="email" autoComplete="email" {...register("email")} /></label>
      {errors.email && <p className="err">{errors.email.message as string}</p>}
      <label>Password<input type="password" autoComplete="current-password" {...register("password")} /></label>
      {errors.password && <p className="err">{errors.password.message as string}</p>}
      {err && <p className="err" role="alert">{err}</p>}
      <button className="btn">Log in</button>
      <p className="muted">New here? <Link to="/register">Create an account</Link></p>
    </form>
  );
}

export function Register() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(regSchema) });
  const { err, submit } = useSubmit("/auth/register");
  return (
    <form className="card narrow" onSubmit={handleSubmit(submit)} noValidate>
      <h2>Create your account</h2>
      <label>Full name<input autoComplete="name" {...register("full_name")} /></label>
      {errors.full_name && <p className="err">{errors.full_name.message as string}</p>}
      <label>Email<input type="email" autoComplete="email" {...register("email")} /></label>
      {errors.email && <p className="err">{errors.email.message as string}</p>}
      <label>Password<input type="password" autoComplete="new-password" {...register("password")} /></label>
      {errors.password && <p className="err">{errors.password.message as string}</p>}
      {err && <p className="err" role="alert">{err}</p>}
      <button className="btn">Create account</button>
      <p className="muted">Already registered? <Link to="/login">Log in</Link></p>
    </form>
  );
}
