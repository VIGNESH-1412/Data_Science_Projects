import { useEffect, useState } from "react";
import { api } from "../api";

export default function Profile() {
  const [p, setP] = useState<any>(null);
  const [msg, setMsg] = useState("");
  useEffect(() => { api("/profile").then(setP); }, []);
  if (!p) return <p className="muted">Loading…</p>;
  const set = (k: string) => (e: any) => setP({ ...p, [k]: e.target.value });
  const save = async (e: any) => {
    e.preventDefault();
    const body = { ...p, skills: typeof p.skills === "string" ? p.skills.split(",").map((s: string) => s.trim()).filter(Boolean) : p.skills };
    setP(await api("/profile", { method: "PUT", body })); setMsg("Profile saved");
  };
  return (
    <form className="card narrow" onSubmit={save}>
      <h2>Profile</h2>
      <label>Target role<input value={p.target_role} onChange={set("target_role")} /></label>
      <label>Skills (comma separated)<input value={Array.isArray(p.skills) ? p.skills.join(", ") : p.skills} onChange={set("skills")} /></label>
      <label>Education<textarea rows={2} value={p.education} onChange={set("education")} /></label>
      <label>Experience<textarea rows={2} value={p.experience} onChange={set("experience")} /></label>
      <label>Interview goals<textarea rows={2} value={p.goals} onChange={set("goals")} /></label>
      <button className="btn">Save profile</button>
      {msg && <p className="ok-text" role="status">{msg}</p>}
    </form>
  );
}
