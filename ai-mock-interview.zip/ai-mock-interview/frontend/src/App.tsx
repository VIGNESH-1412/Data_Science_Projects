import { createContext, useContext, useEffect, useState } from "react";
import { Link, NavLink, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { api } from "./api";
import Landing from "./pages/Landing";
import { Login, Register } from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import ResumePage from "./pages/Resume";
import Configure from "./pages/Configure";
import Interview from "./pages/Interview";
import Results from "./pages/Results";
import Analytics from "./pages/Analytics";

type User = { id: string; email: string; full_name: string } | null;
const Ctx = createContext<{ user: User; setUser: (u: User) => void }>({ user: null, setUser: () => {} });
export const useAuth = () => useContext(Ctx);

function Shell({ children }: { children: React.ReactNode }) {
  const { user, setUser } = useAuth();
  const nav = useNavigate();
  const logout = async () => { await api("/auth/logout", { method: "POST" }); setUser(null); nav("/"); };
  return (
    <>
      <header className="top">
        <Link to={user ? "/dashboard" : "/"} className="brand">Rehearse</Link>
        {user && (
          <nav>
            <NavLink to="/dashboard">Dashboard</NavLink>
            <NavLink to="/interview/new">New interview</NavLink>
            <NavLink to="/resume">Resume</NavLink>
            <NavLink to="/analytics">Progress</NavLink>
            <NavLink to="/profile">Profile</NavLink>
            <button className="link" onClick={logout}>Log out</button>
          </nav>
        )}
      </header>
      <main>{children}</main>
      <footer>Scores are model-based practice estimates, not predictions of hiring outcomes.</footer>
    </>
  );
}

function Private({ children }: { children: JSX.Element }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const [user, setUser] = useState<User>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => { api("/auth/me").then(setUser).catch(() => setUser(null)).finally(() => setReady(true)); }, []);
  if (!ready) return <p className="muted pad">Loading…</p>;
  return (
    <Ctx.Provider value={{ user, setUser }}>
      <Shell>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Private><Dashboard /></Private>} />
          <Route path="/profile" element={<Private><Profile /></Private>} />
          <Route path="/resume" element={<Private><ResumePage /></Private>} />
          <Route path="/interview/new" element={<Private><Configure /></Private>} />
          <Route path="/interview/:id" element={<Private><Interview /></Private>} />
          <Route path="/results/:id" element={<Private><Results /></Private>} />
          <Route path="/analytics" element={<Private><Analytics /></Private>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Shell>
    </Ctx.Provider>
  );
}
