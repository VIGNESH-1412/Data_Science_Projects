# AI Mock Interview & Performance Analyzer

Interview practice/coaching app: FastAPI + SQLAlchemy backend, React/TypeScript/Vite frontend, rubric + embedding-based answer scoring, adaptive question policy, resume analysis, optional Whisper transcription, PDF reports.
It is a coaching tool, **not** a hiring-decision system. All scores are model-based estimates.

## Run locally
```bash
# backend (SQLite by default)
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env              # set SECRET_KEY
uvicorn app.main:app --reload     # http://localhost:8000/docs
# optional voice transcription
pip install faster-whisper==1.1.0

# frontend
cd frontend && npm install && npm run dev    # http://localhost:5173
```
Docker: `echo "SECRET_KEY=$(openssl rand -hex 32)" > .env && docker compose up --build` -> http://localhost:8080

Tests: `cd backend && pip install pytest && pytest` (evaluator/adaptive tests run offline via TF-IDF fallback; API test runs the full flow and checks cross-user isolation).

## Architecture
```
backend/app
  routers/   auth+profile, resumes, interviews (+answers, transcribe), analytics+reports
  services/  question_bank (rubrics), evaluator (scoring), adaptive (policy), resume_parser, analytics, report (PDF)
  models.py  users, candidate_profiles, resumes, model_versions, interview_sessions/questions, candidate_answers,
             evaluation_results, generated_reports, user_feedback, audit_events
backend/ml   prepare_splits.py (dedupe-safe splits), train_eval.py (baseline vs embedding model on YOUR annotations)
frontend/src pages: Landing, Auth, Dashboard, Profile, Resume, Configure, Interview, Results, Analytics
```

## How scoring works (and what it is not)
Overall = weighted mean of dimensions on 0-100; weights depend on question type (`WEIGHTS` in `evaluator.py`). Technical default is 0.40 correctness, 0.25 relevance, 0.20 completeness, 0.15 communication.
- **semantic_relevance**: Sentence-Transformer cosine similarity (TF-IDF fallback if the model can't load). Topical, not proof of correctness.
- **completeness**: weighted coverage of rubric concepts (keyword match, else semantic match to the best answer sentence) with evidence returned.
- **technical_correctness**: rubric-grounded heuristic = coverage minus penalties for listed misconceptions. It cannot verify arbitrary facts; low-evidence cases are flagged `ambiguous_low_evidence`.
- **communication**: filler ratio, repetition, length sanity, sentence length, connectives. Length is never rewarded.
- **star**: cue-based STAR detection with partial credit (behavioral/project answers).
- Speech statistics (WPM, fillers, pauses) are descriptive only. Confidence, honesty, emotion, accent are not measured or scored.
- The adaptive engine is a transparent **rule-based** policy (follow-up on incomplete answers, +/-1 difficulty, weakest-competency-first, no repeats). It is not reinforcement learning.

## Validate before claiming accuracy
No model here is trained and no benchmark numbers are claimed. To evaluate:
1. Collect consented, de-identified answers and ratings (`backend/data/DATASETS.md`).
2. `python -m ml.prepare_splits && python -m ml.train_eval` -> `ml/results.json` (MAE/RMSE/Spearman, by question type and answer length).
3. Tune `WEIGHTS` and rubric concepts using the validation split; report the held-out test split.

## Known limitations / next steps
- Question bank is small (~25 questions); extend `question_bank.py` or load from the DB, and add an LLM generator that must pass the same schema validation.
- Coding questions: no code execution is implemented on purpose. Add a sandbox (e.g. isolated container with CPU/memory/time limits and no network) before enabling it.
- Migrations: tables are auto-created in dev. For production run `alembic init migrations`, point `env.py` at `app.models.Base.metadata`, then `alembic revision --autogenerate`.
- Rate limiting is in-memory; use Redis/gateway limits when running multiple workers. Set `COOKIE_SECURE=true` behind HTTPS.
- Plain CSS is used instead of Tailwind; swap in Tailwind/shadcn if your course requires it.
- Not built: pgvector retrieval, cross-encoder/NLI scoring hook, skill/job_role/template tables (taxonomy and bank live in code).
