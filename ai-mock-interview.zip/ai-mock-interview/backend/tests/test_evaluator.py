import os
os.environ["USE_EMBEDDINGS"] = "false"  # keep unit tests fast/offline; exercises the TF-IDF fallback path

from app.services import adaptive, evaluator
from app.services.question_bank import BANK
from app.services.resume_parser import compatibility, find_skills


def q(bank_id):
    b = next(x for x in BANK if x["id"] == bank_id)
    return {"text": b["text"], "qtype": b["type"], "rubric": {"concepts": b["concepts"], "misconceptions": b["misconceptions"],
                                                              "reference": b["reference"], "followups": b["followups"]}}


GOOD = ("An inner join returns only matching rows from both tables. A left join keeps all rows from the left table, "
        "and the unmatched right side becomes NULL. For example, customers joined to orders shows customers with no orders.")
BAD = "I like databases and think they are very useful for storing things."


def test_good_beats_bad_and_scores_in_range():
    g, b = evaluator.evaluate(q("sql-joins"), GOOD), evaluator.evaluate(q("sql-joins"), BAD)
    assert g["overall"] > b["overall"] + 25
    for r in (g, b):
        assert 0 <= r["overall"] <= 100 and all(0 <= v <= 100 for v in r["components"].values())


def test_misconception_penalised():
    r = evaluator.evaluate(q("py-mutability"), "Tuples are mutable and lists are immutable in Python.")
    assert "possible_misconception" in r["details"]["flags"]
    assert r["feedback"]["errors"]


def test_skipped_scores_zero():
    r = evaluator.evaluate(q("sql-joins"), "", skipped=True)
    assert r["overall"] == 0 and "unanswered" in r["details"]["flags"]


def test_length_not_rewarded():
    padded = GOOD + " " + "It is very important and useful. " * 40
    assert evaluator.evaluate(q("sql-joins"), padded)["components"]["communication"] < evaluator.evaluate(q("sql-joins"), GOOD)["components"]["communication"]


def test_star_partial_credit():
    r = evaluator.evaluate(q("beh-deadline"), "During my semester project I had to submit in two days. I planned tasks and I built the dashboard. As a result we delivered on time.")
    assert r["components"]["star"] >= 75


def test_adaptive_followup_and_no_repeat():
    cfg = {"role": "Data Analyst", "difficulty": "medium", "num_questions": 6, "skills": [], "plan": adaptive.build_plan("technical", 6, False)}
    first, _ = adaptive.pick_next(cfg, [], [])
    asked = [{"id": "1", "bank_id": first["id"], "competency": first["competency"], "qtype": first["type"], "difficulty": first["difficulty"],
              "is_followup": False, "parent_id": None, "overall": 40, "completeness": 30, "missing": [first["concepts"][0]["name"]],
              "followups": first["followups"], "concepts": first["concepts"], "reference": first["reference"]}]
    nxt, reason = adaptive.pick_next(cfg, asked, [])
    assert nxt["id"].endswith("-fu") and "follow-up" in reason
    asked.append({**asked[0], "id": "2", "bank_id": nxt["id"], "is_followup": True, "parent_id": "1", "overall": 80, "completeness": 90, "missing": []})
    third, _ = adaptive.pick_next(cfg, asked, [])
    assert third["id"] != first["id"]


def test_resume_skills_and_compat():
    s = find_skills("Skills: Python, SQL, C++, Power BI. Built dashboards.")
    assert {"python", "sql", "c++", "power bi"} <= set(s)
    assert compatibility(s, "Need SQL and Tableau")["missing"] == ["tableau"]
