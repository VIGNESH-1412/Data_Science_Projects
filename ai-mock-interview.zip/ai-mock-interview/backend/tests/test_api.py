import os
os.environ.update(DATABASE_URL="sqlite:///./test.db", USE_EMBEDDINGS="false", UPLOAD_DIR="./test_uploads")
from fastapi.testclient import TestClient

from app.main import app


def client():
    return TestClient(app)


def test_full_flow_and_isolation():
    with client() as a, client() as b:
        assert a.post("/api/v1/auth/register", json={"email": "a@x.com", "password": "password123", "full_name": "A"}).status_code in (201, 409)
        a.post("/api/v1/auth/login", json={"email": "a@x.com", "password": "password123"})
        b.post("/api/v1/auth/register", json={"email": "b@x.com", "password": "password123", "full_name": "B"})
        r = a.post("/api/v1/interviews", json={"role": "Data Analyst", "interview_type": "technical", "num_questions": 3})
        iid = r.json()["id"]
        assert b.get(f"/api/v1/interviews/{iid}").status_code == 404          # other user cannot read it
        q = a.post(f"/api/v1/interviews/{iid}/start").json()["question"]
        ans = a.post(f"/api/v1/interviews/{iid}/answers", json={"question_id": q["id"], "text": "I think it joins tables together."})
        assert ans.status_code == 201 and 0 <= ans.json()["evaluation"]["overall"] <= 100
        assert a.post(f"/api/v1/interviews/{iid}/complete").json()["summary"]["answered"] == 1
        assert a.get(f"/api/v1/interviews/{iid}/results").status_code == 200
        pdf = a.post(f"/api/v1/interviews/{iid}/report")
        assert pdf.status_code == 201 and a.get(pdf.json()["download"]).headers["content-type"] == "application/pdf"
        assert b.get(pdf.json()["download"]).status_code == 404
        assert a.get("/api/v1/analytics/performance").status_code == 200


def test_unauthenticated():
    assert client().get("/api/v1/interviews").status_code == 401
