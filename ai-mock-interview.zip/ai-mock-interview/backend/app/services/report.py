import os

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from xml.sax.saxutils import escape

DISCLAIMER = ("This report contains model-based practice estimates. Scores come from rubric features, embedding similarity and heuristics whose "
              "weights are not validated as predictors of real interview outcomes. This tool is for coaching only and must not be used for hiring decisions.")


def build_pdf(path: str, session, summary: dict, rows, plan: list[dict], candidate: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    ss = getSampleStyleSheet()
    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm)
    p = lambda t, s="BodyText": Paragraph(escape(str(t)), ss[s])
    cfg = session.config
    el = [p("Interview Performance Report", "Title"), p(f"Candidate: {candidate}")]
    el += [p(f"Role: {cfg['role']} | Level: {cfg['level']} | Type: {cfg['interview_type']} | Difficulty: {cfg['difficulty']} | Mode: {cfg['mode']}")]
    dur = ""
    if session.started_at and session.completed_at:
        dur = f"{int((session.completed_at - session.started_at).total_seconds() // 60)} min"
    el += [p(f"Date: {session.completed_at:%Y-%m-%d %H:%M} | Duration: {dur}" if session.completed_at else "Date: n/a"), Spacer(1, 6)]
    el += [p("Summary scores (0-100, estimates)", "Heading2")]
    data = [["Dimension", "Score"], ["Overall", summary.get("overall", 0)]] + [[k.replace("_", " ").title(), v] for k, v in summary.get("dimensions", {}).items()]
    t = Table(data, colWidths=[90 * mm, 30 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#14213d")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("GRID", (0, 0), (-1, -1), 0.4, colors.grey)]))
    el += [t, Spacer(1, 8), p("Competency analysis", "Heading2")]
    for c, v in sorted(summary.get("competencies", {}).items(), key=lambda x: x[1]):
        el.append(p(f"{c}: {v}  ({'strength' if v >= 70 else 'needs work' if v < 55 else 'developing'})"))
    el += [Spacer(1, 8), p("Question-by-question feedback", "Heading2")]
    for i, (q, a, e) in enumerate(rows, 1):
        el += [p(f"Q{i}. {q.text}", "Heading4"), p(f"Score {e.overall} | {q.competency} | {q.difficulty}"),
               p("Your answer: " + (a.text or "(skipped)"))]
        fb = e.feedback
        if fb.get("did_well"):
            el.append(p("Did well: " + " ".join(fb["did_well"])))
        if fb.get("missing"):
            el.append(p("Missing: " + "; ".join(fb["missing"])))
        if fb.get("errors"):
            el.append(p("Possible errors: " + " ".join(fb["errors"])))
        el += [p("Stronger answer: " + fb.get("stronger_answer", "")), Spacer(1, 6)]
    el.append(p("Learning roadmap", "Heading2"))
    el += [p("- " + x["action"]) for x in plan] or [p("No repeated weaknesses detected yet. Keep practising across sessions.")]
    el += [Spacer(1, 10), p("Disclaimer", "Heading3"), p(DISCLAIMER)]
    doc.build(el)
