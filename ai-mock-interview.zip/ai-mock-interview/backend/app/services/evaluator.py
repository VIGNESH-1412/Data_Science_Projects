"""Multi-signal answer evaluator.

Signals (each 0-100):
  semantic_relevance  - embedding cosine between answer and (question + reference), rescaled. TOPICAL, not proof of correctness.
  completeness        - weighted rubric-concept coverage (lexical match, else embedding match to best answer sentence).
  technical_correctness - rubric-grounded: concept coverage minus penalties for known misconceptions. It is a HEURISTIC:
                        it can't verify arbitrary facts. Low-evidence cases are flagged "ambiguous".
  communication       - structure/clarity features (filler ratio, repetition, length sanity, sentence length, connectives).
  star                - STAR-inspired cue detection for behavioral/project answers (partial credit).
Weights are a HYPOTHESIS and are not validated; see ml/ for the human-rating validation pipeline.
Without sentence-transformers installed, a TF-IDF similarity fallback is used (weaker; flagged in model_version).
"""
import re
from collections import Counter

from ..config import settings

RUBRIC_VERSION = "rubric-v0.1"

WEIGHTS = {
    "technical": {"technical_correctness": 0.40, "semantic_relevance": 0.25, "completeness": 0.20, "communication": 0.15},
    "situational": {"semantic_relevance": 0.30, "completeness": 0.45, "communication": 0.25},
    "behavioral": {"star": 0.35, "semantic_relevance": 0.15, "completeness": 0.25, "communication": 0.25},
    "project": {"star": 0.30, "semantic_relevance": 0.15, "completeness": 0.30, "communication": 0.25},
    "hr": {"semantic_relevance": 0.30, "completeness": 0.30, "communication": 0.40},
}
FILLERS = ["um", "uh", "you know", "basically", "sort of", "kind of", "i mean", "i guess", "you see"]
CONNECTIVES = ["first", "second", "then", "because", "therefore", "for example", "finally", "however", "as a result", "so that", "in addition"]

_model = None
_tried = False


def _get_model():
    global _model, _tried
    if _tried:
        return _model
    _tried = True
    if not settings.use_embeddings:
        return None
    try:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(settings.embed_model)
    except Exception:
        _model = None
    return _model


def model_version() -> str:
    return settings.embed_model if _get_model() else "tfidf-fallback"


def similarity_matrix(a: list[str], b: list[str]):
    import numpy as np
    m = _get_model()
    if m is not None:
        ea = m.encode(a, normalize_embeddings=True)
        eb = m.encode(b, normalize_embeddings=True)
        return np.asarray(ea) @ np.asarray(eb).T
    from sklearn.feature_extraction.text import TfidfVectorizer
    vec = TfidfVectorizer(stop_words="english").fit(a + b)
    return (vec.transform(a) @ vec.transform(b).T).toarray()


def _thresholds() -> dict:
    if _get_model() is not None:
        return {"lo": 0.15, "hi": 0.65, "concept": 0.50}
    return {"lo": 0.02, "hi": 0.30, "concept": 0.28}


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [p.strip() for p in parts if len(p.split()) >= 3]


def words(text: str) -> list[str]:
    return re.findall(r"[\w']+", text.lower())


def _clip(x: float) -> float:
    return max(0.0, min(100.0, x))


def semantic_relevance(question: str, reference: str, answer: str) -> float:
    if not answer.strip():
        return 0.0
    t = _thresholds()
    sims = similarity_matrix([answer], [question + " " + reference, reference])[0]
    s = float(max(sims))
    return _clip((s - t["lo"]) / (t["hi"] - t["lo"]) * 100)


def concept_coverage(answer: str, concepts: list[dict]) -> list[dict]:
    low = answer.lower()
    sents = split_sentences(answer) or ([answer] if answer.strip() else [])
    t = _thresholds()
    sim = None
    if sents:
        texts = [c["name"] + " " + " ".join(c["keywords"][:4]) for c in concepts]
        sim = similarity_matrix(texts, sents)
    out = []
    for i, c in enumerate(concepts):
        hit = next((k for k in c["keywords"] if k.lower() in low), None)
        if hit:
            ev = next((s for s in sents if hit.lower() in s.lower()), answer[:160])
            out.append({"concept": c["name"], "weight": c["weight"], "score": 1.0, "method": "keyword", "evidence": ev[:200]})
            continue
        if sim is not None:
            j = int(sim[i].argmax())
            if float(sim[i][j]) >= t["concept"]:
                out.append({"concept": c["name"], "weight": c["weight"], "score": 0.7, "method": "semantic", "evidence": sents[j][:200]})
                continue
        out.append({"concept": c["name"], "weight": c["weight"], "score": 0.0, "method": "none", "evidence": ""})
    return out


def completeness_from(cov: list[dict]) -> float:
    tw = sum(c["weight"] for c in cov) or 1
    return _clip(sum(c["weight"] * c["score"] for c in cov) / tw * 100)


def find_misconceptions(answer: str, misconceptions: list[dict]) -> list[dict]:
    return [m for m in misconceptions if re.search(m["pattern"], answer, flags=re.I)]


def communication_quality(text: str) -> tuple[float, dict]:
    w = words(text)
    n = len(w)
    if n == 0:
        return 0.0, {"word_count": 0}
    low = text.lower()
    fillers = sum(len(re.findall(r"\b" + re.escape(f) + r"\b", low)) for f in FILLERS)
    tri = [tuple(w[i:i + 3]) for i in range(max(0, n - 2))]
    rep = 1 - len(set(tri)) / len(tri) if tri else 0.0
    sents = split_sentences(text) or [text]
    avg_len = n / len(sents)
    conn = sum(1 for c in CONNECTIVES if c in low)
    score = 100.0
    score -= min(40, fillers / n * 400)
    score -= min(25, rep * 100)
    if n < 20:
        score -= (20 - n) * 2.0           # too little to judge clarity
    if n > 350:
        score -= min(15, (n - 350) / 20)  # length alone is never rewarded
    if avg_len > 35:
        score -= 10
    if conn >= 2:
        score += 5
    return _clip(score), {"word_count": n, "filler_count": fillers, "repeated_trigram_ratio": round(rep, 3),
                          "avg_sentence_len": round(avg_len, 1), "connectives": conn}


STAR_CUES = {
    "situation": [r"\bwhen\b", r"\bduring\b", r"\bsituation\b", r"\bcontext\b", r"\bproject\b", r"\binternship\b", r"\bsemester\b", r"\bat my\b", r"\blast (year|month)\b"],
    "task": [r"\bresponsible\b", r"\bmy role\b", r"\bgoal\b", r"\bneeded to\b", r"\bhad to\b", r"\btask\b", r"\bobjective\b", r"\bassigned\b"],
    "action": [r"\bi (?:\w+ed|built|led|wrote|made|ran|took|chose|decided|created|set|broke|split|organi[sz]ed)\b"],
    "result": [r"\bresult\b", r"\boutcome\b", r"\bas a result\b", r"\bimproved\b", r"\breduced\b", r"\bincreased\b", r"\bsaved\b", r"\bdelivered\b", r"\bachieved\b", r"\d+\s?%", r"\bon time\b"],
}


def star_score(text: str) -> tuple[float, dict]:
    low = text.lower()
    comp = {}
    for part, pats in STAR_CUES.items():
        hits = sum(1 for p in pats if re.search(p, low))
        comp[part] = 1.0 if hits >= 2 else (0.5 if hits == 1 else 0.0)
    return _clip(sum(comp.values()) / 4 * 100), comp


def speech_metrics(text: str, duration_sec, segments: list[dict], asr_conf) -> dict:
    w = words(text)
    m = {"word_count": len(w)}
    if duration_sec and duration_sec > 0:
        m["speaking_duration_sec"] = round(duration_sec, 1)
        m["words_per_minute"] = round(len(w) / (duration_sec / 60), 1)
    low = text.lower()
    m["filler_count"] = sum(len(re.findall(r"\b" + re.escape(f) + r"\b", low)) for f in FILLERS)
    m["filler_words_per_100"] = round(m["filler_count"] / len(w) * 100, 1) if w else 0
    tri = Counter(tuple(w[i:i + 3]) for i in range(max(0, len(w) - 2)))
    m["repeated_phrases"] = [" ".join(k) for k, v in tri.items() if v >= 3][:5]
    if segments:
        ends = [s.get("end") for s in segments]
        starts = [s.get("start") for s in segments]
        gaps = [b - a for a, b in zip(ends, starts[1:]) if a is not None and b is not None]
        m["long_pauses_over_2s"] = sum(1 for g in gaps if g > 2.0)
    if asr_conf is not None:
        m["asr_confidence"] = round(float(asr_conf), 3)
    m["note"] = "Descriptive speech statistics only. Not used as a proxy for confidence, honesty or ability; accents/speech differences are not scored."
    return m


STRUCTURE_TIPS = {
    "technical": "Definition -> how it works -> short example -> trade-off or when to use it.",
    "behavioral": "STAR: Situation, Task, Action (what YOU did), Result (measurable), then one lesson.",
    "project": "Goal -> your role -> key technical decisions and why -> result -> challenge and lesson.",
    "situational": "Clarify the problem -> investigate -> act -> communicate -> prevent recurrence.",
    "hr": "Present -> past -> future, tied to the role in under two minutes.",
}


def build_feedback(q: dict, cov: list[dict], miscs: list[dict], comp: dict, star: dict | None, flags: list[str]) -> dict:
    covered = [c["concept"] for c in cov if c["score"] > 0]
    missing = [c["concept"] for c in cov if c["score"] == 0]
    did_well = [f"You covered: {c}." for c in covered[:4]]
    if comp.get("communication", 0) >= 75:
        did_well.append("Your answer was clearly worded with little repetition or filler.")
    if star:
        did_well += [f"You described the {p}." for p, v in star.items() if v >= 1]
    fup = q["rubric"].get("followups", {})
    practice = next((fup[m] for m in missing if m in fup), None) or (
        f"Explain, in your own words: {missing[0]}." if missing else "Try the same question again in under 90 seconds.")
    fb = {
        "did_well": did_well or ["You made an attempt; build on it using the structure below."],
        "missing": missing,
        "errors": [m["note"] for m in miscs],
        "correct_concepts": q["rubric"]["reference"],
        "stronger_answer": q["rubric"]["reference"],
        "structure_tip": STRUCTURE_TIPS.get(q["qtype"], STRUCTURE_TIPS["technical"]),
        "revise_topics": missing[:5],
        "practice_question": practice,
        "caution": None,
    }
    if "ambiguous_low_evidence" in flags:
        fb["caution"] = "Only paraphrase-level evidence was found for some points, so this score is less certain. Review the reference answer and flag the result if you think it is unfair."
    if "very_short_answer" in flags:
        fb["caution"] = "Your answer was very short, so the system had little to evaluate."
    return fb


def evaluate(q: dict, text: str, skipped: bool = False) -> dict:
    """q: dict with text, qtype, rubric{concepts, misconceptions, reference, followups}."""
    rub = q["rubric"]
    qtype = q["qtype"] if q["qtype"] in WEIGHTS else "technical"
    weights = WEIGHTS[qtype]
    flags: list[str] = []
    text = (text or "").strip()
    if skipped or not text:
        comp = {k: 0.0 for k in weights}
        cov = [{"concept": c["name"], "weight": c["weight"], "score": 0.0, "method": "none", "evidence": ""} for c in rub["concepts"]]
        flags.append("unanswered")
        return {"overall": 0.0, "components": comp, "details": {"coverage": cov, "misconceptions": [], "flags": flags, "weights": weights, "communication_features": {}},
                "feedback": build_feedback(q, cov, [], comp, None, flags), "model_version": model_version(), "rubric_version": RUBRIC_VERSION}

    cov = concept_coverage(text, rub["concepts"])
    miscs = find_misconceptions(text, rub.get("misconceptions", []))
    completeness = completeness_from(cov)
    relevance = semantic_relevance(q["text"], rub["reference"], text)
    comm, comm_feats = communication_quality(text)
    comp = {"semantic_relevance": relevance, "completeness": completeness, "communication": comm}

    star = None
    if "technical_correctness" in weights:
        penalty = min(60, 20 * len(miscs))
        tc = completeness - penalty
        if comm_feats["word_count"] < 10:
            tc = min(tc, 40)
            flags.append("very_short_answer")
        sem_only = [c for c in cov if c["method"] == "semantic"]
        if sem_only and len(sem_only) >= len([c for c in cov if c["score"] > 0]) / 2:
            flags.append("ambiguous_low_evidence")
        if relevance >= 60 and completeness < 25:
            flags.append("on_topic_but_missing_key_concepts")
        comp["technical_correctness"] = _clip(tc)
    if "star" in weights:
        s, star = star_score(text)
        comp["star"] = s
        if comm_feats["word_count"] < 25:
            flags.append("very_short_answer")
    if miscs:
        flags.append("possible_misconception")

    tw = sum(weights.values())
    overall = _clip(sum(weights[k] * comp[k] for k in weights) / tw)
    return {
        "overall": round(overall, 1),
        "components": {k: round(v, 1) for k, v in comp.items()},
        "details": {"coverage": cov, "misconceptions": miscs, "flags": flags, "weights": weights,
                    "communication_features": comm_feats, "star": star,
                    "note": "Model-based estimate; weights are an unvalidated starting hypothesis."},
        "feedback": build_feedback(q, cov, miscs, comp, star, flags),
        "model_version": model_version(), "rubric_version": RUBRIC_VERSION,
    }
