from collections import Counter, defaultdict

from sqlalchemy.orm import Session

from ..models import CandidateAnswer, InterviewQuestion, InterviewSession, EvaluationResult


def session_rows(db: Session, user_id: str, session_id: str | None = None):
    q = (db.query(InterviewQuestion, CandidateAnswer, EvaluationResult)
         .join(CandidateAnswer, CandidateAnswer.question_id == InterviewQuestion.id)
         .join(EvaluationResult, EvaluationResult.answer_id == CandidateAnswer.id)
         .join(InterviewSession, InterviewSession.id == InterviewQuestion.session_id)
         .filter(InterviewSession.user_id == user_id))
    if session_id:
        q = q.filter(InterviewSession.id == session_id)
    return q.order_by(InterviewQuestion.order_index).all()


def summarize(rows) -> dict:
    if not rows:
        return {"overall": 0, "dimensions": {}, "competencies": {}, "answered": 0, "skipped": 0}
    dims: dict[str, list[float]] = defaultdict(list)
    comps: dict[str, list[float]] = defaultdict(list)
    skipped = 0
    for q, a, e in rows:
        for k, v in e.components.items():
            dims[k].append(v)
        comps[q.competency].append(e.overall)
        skipped += int(a.skipped)
    avg = lambda xs: round(sum(xs) / len(xs), 1)
    return {
        "overall": avg([e.overall for _, _, e in rows]),
        "dimensions": {k: avg(v) for k, v in dims.items()},
        "competencies": {k: avg(v) for k, v in comps.items()},
        "answered": len(rows) - skipped, "skipped": skipped,
        "disclaimer": "Practice scores are model-based estimates, not predictions of real interview outcomes.",
    }


def skill_gaps(db: Session, user_id: str) -> dict:
    rows = session_rows(db, user_id)
    by_comp: dict[str, list[float]] = defaultdict(list)
    missing = defaultdict(Counter)
    per_session: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for q, a, e in rows:
        by_comp[q.competency].append(e.overall)
        per_session[q.session_id][q.competency].append(e.overall)
        for m in e.feedback.get("missing", []):
            missing[q.competency][m] += 1
    heat = [{"competency": c, "average": round(sum(v) / len(v), 1), "attempts": len(v)} for c, v in by_comp.items()]
    heat.sort(key=lambda x: x["average"])
    plan = []
    for h in heat:
        # recommendation only for REPEATED weakness (>=2 attempts) or very low score
        if h["average"] < 60 and (h["attempts"] >= 2 or h["average"] < 35):
            topics = [t for t, _ in missing[h["competency"]].most_common(4)]
            plan.append({"competency": h["competency"], "average": h["average"], "attempts": h["attempts"], "priority": "high" if h["average"] < 45 else "medium",
                         "topics": topics, "action": f"Revise {', '.join(topics) or h['competency']} and re-practice 2-3 {h['competency']} questions."})
    return {"heatmap": heat, "learning_plan": plan}


def progress(db: Session, user_id: str) -> list[dict]:
    sessions = (db.query(InterviewSession).filter_by(user_id=user_id, status="completed")
                .order_by(InterviewSession.completed_at).all())
    return [{"id": s.id, "date": s.completed_at.isoformat() if s.completed_at else None, "role": s.config.get("role"),
             "overall": s.summary.get("overall"), "dimensions": s.summary.get("dimensions", {})} for s in sessions]
