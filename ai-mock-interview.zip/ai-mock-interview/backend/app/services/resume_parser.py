"""Resume text extraction + taxonomy-based skill extraction.
Everything returned is EXTRACTED from the document and is NOT verified."""
import re
from pathlib import Path

TAXONOMY = {
    "Programming": ["python", "java", "javascript", "typescript", "c++", "c#", "go", "r", "scala", "bash"],
    "Data & Databases": ["sql", "mysql", "postgresql", "mongodb", "pandas", "numpy", "excel", "etl", "data cleaning", "database"],
    "Visualization / BI": ["power bi", "tableau", "matplotlib", "seaborn", "dax", "visualization", "dashboard"],
    "Machine Learning": ["machine learning", "scikit-learn", "tensorflow", "pytorch", "nlp", "deep learning", "regression", "classification", "clustering", "xgboost"],
    "Statistics": ["statistics", "hypothesis testing", "a/b testing", "probability"],
    "Web & Tools": ["react", "fastapi", "flask", "django", "rest", "api", "docker", "git", "github", "linux", "aws"],
}
ALL_SKILLS = [s for v in TAXONOMY.values() for s in v]
SECTION_RE = re.compile(r"^\s*(education|experience|work experience|projects?|skills|certifications?|summary|internships?)\s*:?\s*$", re.I | re.M)


def extract_text(path: str, filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages)
    if ext == ".docx":
        import docx
        d = docx.Document(path)
        return "\n".join(p.text for p in d.paragraphs)
    raise ValueError("Unsupported file type")


def find_skills(text: str) -> list[str]:
    low = text.lower()
    found = []
    for s in ALL_SKILLS:
        pat = r"(?<![\w+#])" + re.escape(s) + r"(?![\w+#])"
        if re.search(pat, low):
            found.append(s)
    return found


def sections(text: str) -> dict:
    marks = [(m.start(), m.end(), m.group(1).lower()) for m in SECTION_RE.finditer(text)]
    out = {}
    for i, (_, end, name) in enumerate(marks):
        nxt = marks[i + 1][0] if i + 1 < len(marks) else len(text)
        out[name] = text[end:nxt].strip()[:800]
    return out


def analyze(text: str) -> dict:
    skills = find_skills(text)
    cats = {c: [s for s in skills if s in v] for c, v in TAXONOMY.items()}
    secs = sections(text)
    return {
        "disclaimer": "Extracted automatically; not verified.",
        "char_count": len(text),
        "skills": skills,
        "skills_by_category": {k: v for k, v in cats.items() if v},
        "sections_detected": list(secs.keys()),
        "education": secs.get("education", ""),
        "experience": secs.get("experience", secs.get("work experience", secs.get("internships", ""))),
        "projects": secs.get("projects", secs.get("project", "")),
        "suggested_topics": skills[:8],
    }


def compatibility(resume_skills: list[str], job_text: str) -> dict:
    jd = find_skills(job_text)
    if not jd:
        return {"score": None, "matched": [], "missing": [], "note": "No known skills found in the job description."}
    matched = [s for s in jd if s in resume_skills]
    missing = [s for s in jd if s not in resume_skills]
    return {"score": round(len(matched) / len(jd) * 100), "matched": matched, "missing": missing,
            "note": "Keyword overlap against a fixed taxonomy; not a hiring signal."}
