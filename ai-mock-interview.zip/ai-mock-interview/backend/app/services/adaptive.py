"""Transparent rule-based adaptive policy (NOT reinforcement learning).
Rules: (1) follow up once on incomplete answers, (2) difficulty +1 after two strong main answers,
-1 after two weak ones, (3) cover competencies evenly, weakest first, (4) never repeat a question."""
import random

from .question_bank import BANK, LEVELS, NAMES, project_question

MIX = {
    "technical": ["technical"],
    "hr": ["hr", "hr", "situational"],
    "behavioral": ["behavioral", "situational"],
    "managerial": ["behavioral", "situational", "hr"],
    "mixed": ["technical", "technical", "behavioral", "technical", "hr", "situational"],
}


def build_plan(interview_type: str, n: int, has_projects: bool) -> list[str]:
    pattern = MIX[interview_type]
    plan = [pattern[i % len(pattern)] for i in range(n)]
    if has_projects and n >= 4 and "technical" in pattern:
        plan[1] = "project"
    return plan


def _eligible(q: dict, role: str, skills: list[str]) -> bool:
    role = role.lower()
    roles = q["roles"]
    role_ok = "all" in roles or any(r in role or role in r for r in roles)
    if q["type"] in ("technical",) and not role_ok:
        # fall back: allow any technical question if role unknown to the bank
        known = {r for qq in BANK for r in qq["roles"] if r != "all"}
        return not any(k in role or role in k for k in known)
    return role_ok


def _target_level(config: dict, main_scores: list[float]) -> int:
    base = LEVELS[config["difficulty"]]
    if len(main_scores) >= 2:
        last = main_scores[-2:]
        if all(s >= 75 for s in last):
            base += 1
        elif all(s <= 40 for s in last):
            base -= 1
    return max(1, min(3, base))


def pick_next(config: dict, asked: list[dict], resume_skills: list[str]) -> tuple[dict | None, str]:
    """asked: list of dicts {bank_id, competency, qtype, difficulty, is_followup, overall (or None), missing[], id, followups{}}
    Returns (question dict, reason)."""
    answered = [a for a in asked if a.get("overall") is not None]
    main = [a for a in asked if not a["is_followup"]]
    total_limit = config["num_questions"]
    if len(asked) >= total_limit:
        return None, "question limit reached"

    # Rule 1: one follow-up when last answer was incomplete
    if answered:
        last = answered[-1]
        has_fu = any(a.get("parent_id") == last["id"] for a in asked)
        if (not last["is_followup"] and not has_fu and last.get("completeness", 100) < 60 and last.get("missing")
                and last["qtype"] in ("technical", "project") and len(asked) < total_limit - 1 and last["overall"] > 0):
            concept = last["missing"][0]
            text = last.get("followups", {}).get(concept) or f"Can you go deeper on this point: {concept.lower()}?"
            return ({"id": f"{last['bank_id']}-fu", "type": last["qtype"], "competency": last["competency"], "difficulty": last["difficulty"],
                     "text": text, "concepts": [c for c in last["concepts"] if c["name"] == concept] or last["concepts"][:1],
                     "misconceptions": [], "reference": last["reference"], "followups": {}, "time": 90,
                     "_followup_of": last["id"]}, f"follow-up: '{concept}' was not covered")

    plan = config["plan"]
    want_type = plan[min(len(main), len(plan) - 1)]
    level = _target_level(config, [a["overall"] for a in main if a.get("overall") is not None])
    used = {a["bank_id"] for a in asked}
    skills = [s.lower() for s in (config.get("skills") or [])]

    pool: list[dict] = []
    if want_type == "project":
        for s in resume_skills[:6]:
            pq = project_question(s)
            if pq["id"] not in used:
                pool.append(pq)
    else:
        pool = [q for q in BANK if q["type"] == want_type and q["id"] not in used and _eligible(q, config["role"], skills)]
    if not pool:  # fallback to any unused, eligible question
        pool = [q for q in BANK if q["id"] not in used and _eligible(q, config["role"], skills)]
    if not pool:
        return None, "question bank exhausted"

    comp_count: dict[str, int] = {}
    comp_scores: dict[str, list[float]] = {}
    for a in main:
        comp_count[a["competency"]] = comp_count.get(a["competency"], 0) + 1
        if a.get("overall") is not None:
            comp_scores.setdefault(a["competency"], []).append(a["overall"])

    def key(q):
        c = q["competency"]
        avg = sum(comp_scores.get(c, [50])) / len(comp_scores.get(c, [50]))
        skill_bonus = 0 if (not skills or any(s in q["skills"] for s in skills)) else 1
        return (skill_bonus, comp_count.get(c, 0), abs(LEVELS[q["difficulty"]] - level), avg, random.random())

    pool.sort(key=key)
    q = pool[0]
    return q, f"{want_type} question, target difficulty {NAMES[level]}, competency '{q['competency']}' (coverage so far: {comp_count.get(q['competency'], 0)})"
