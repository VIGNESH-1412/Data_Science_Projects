import os


class Settings:
    database_url = os.getenv("DATABASE_URL", "sqlite:///./app.db")
    secret_key = os.getenv("SECRET_KEY", "dev-only-change-me")
    token_minutes = int(os.getenv("TOKEN_MINUTES", "60"))
    upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
    max_upload_mb = int(os.getenv("MAX_UPLOAD_MB", "5"))
    cookie_secure = os.getenv("COOKIE_SECURE", "false").lower() == "true"
    cors_origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
    embed_model = os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    use_embeddings = os.getenv("USE_EMBEDDINGS", "true").lower() == "true"
    whisper_model = os.getenv("WHISPER_MODEL", "base")


settings = Settings()
