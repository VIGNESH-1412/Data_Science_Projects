from typing import Literal, Optional

from pydantic import BaseModel, EmailStr, Field


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(min_length=1, max_length=120)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ProfileIO(BaseModel):
    target_role: str = ""
    education: str = ""
    experience: str = ""
    skills: list[str] = []
    goals: str = ""


class InterviewCreate(BaseModel):
    role: str = Field(min_length=2, max_length=120)
    level: Literal["fresher", "junior", "intermediate", "senior"] = "fresher"
    interview_type: Literal["technical", "hr", "behavioral", "managerial", "mixed"] = "mixed"
    difficulty: Literal["easy", "medium", "hard"] = "medium"
    num_questions: int = Field(6, ge=3, le=20)
    duration_minutes: int = Field(30, ge=5, le=90)
    skills: list[str] = []
    job_description: str = Field("", max_length=8000)
    mode: Literal["text", "voice"] = "text"
    resume_id: Optional[str] = None


class AnswerIn(BaseModel):
    question_id: str
    text: str = Field("", max_length=8000)
    skipped: bool = False
    duration_sec: Optional[float] = Field(None, ge=0, le=3600)
    via_voice: bool = False
    original_transcript: Optional[str] = None
    speech_segments: list[dict] = []
    asr_confidence: Optional[float] = None


class ReEvalIn(BaseModel):
    text: str = Field(max_length=8000)


class FeedbackIn(BaseModel):
    kind: Literal["unfair_score", "transcript_error", "other"]
    comment: str = Field("", max_length=2000)
