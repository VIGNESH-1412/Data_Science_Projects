from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .db import Base, engine
from .routers import auth, interviews, reports_analytics, resumes


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Dev convenience. In production run `alembic upgrade head` instead (see README).
    Base.metadata.create_all(engine)
    yield


app = FastAPI(title="AI Mock Interview & Performance Analyzer", version="0.1.0", lifespan=lifespan,
              description="Interview practice/coaching API. Scores are model-based estimates, not hiring decisions.")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def security_headers(request, call_next):
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    return resp


for r in (auth.router, resumes.router, interviews.router, reports_analytics.router):
    app.include_router(r, prefix="/api/v1")


@app.get("/health")
def health():
    return {"status": "ok"}
