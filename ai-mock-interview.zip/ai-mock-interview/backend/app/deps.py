import time
from collections import defaultdict, deque

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .db import get_db
from .models import AuditEvent, User
from .security import decode_token


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get("access_token")
    user_id = decode_token(token) if token else None
    user = db.get(User, user_id) if user_id else None
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(key: str, limit: int, window_sec: int) -> None:
    """Tiny in-memory limiter (single process). Use Redis or a gateway in production."""
    now = time.time()
    q = _hits[key]
    while q and q[0] < now - window_sec:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Too many requests, try again later")
    q.append(now)


def audit(db: Session, user_id: str | None, action: str, detail: str = "") -> None:
    db.add(AuditEvent(user_id=user_id, action=action, detail=detail))
    db.commit()
