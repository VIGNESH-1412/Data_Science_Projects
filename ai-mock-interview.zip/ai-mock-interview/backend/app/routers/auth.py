from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import audit, get_current_user, rate_limit
from ..models import CandidateProfile, User
from ..schemas import LoginIn, ProfileIO, RegisterIn
from ..security import create_token, hash_password, verify_password

router = APIRouter(tags=["auth"])


def _set_cookie(resp: Response, user_id: str) -> None:
    resp.set_cookie("access_token", create_token(user_id), httponly=True, samesite="lax",
                    secure=settings.cookie_secure, max_age=settings.token_minutes * 60, path="/")


def _user_out(u: User) -> dict:
    return {"id": u.id, "email": u.email, "full_name": u.full_name}


@router.post("/auth/register", status_code=201)
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    rate_limit(f"reg:{request.client.host}", 10, 3600)
    email = body.email.lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "Email already registered")
    u = User(email=email, password_hash=hash_password(body.password), full_name=body.full_name.strip())
    u.profile = CandidateProfile()
    db.add(u)
    db.commit()
    audit(db, u.id, "register")
    _set_cookie(response, u.id)
    return _user_out(u)


@router.post("/auth/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    rate_limit(f"login:{request.client.host}", 10, 300)
    u = db.query(User).filter_by(email=body.email.lower()).first()
    if not u or not verify_password(body.password, u.password_hash):
        audit(db, None, "login_failed", body.email.lower())
        raise HTTPException(401, "Invalid email or password")
    audit(db, u.id, "login")
    _set_cookie(response, u.id)
    return _user_out(u)


@router.post("/auth/logout", status_code=204)
def logout(response: Response):
    response.delete_cookie("access_token", path="/")


@router.get("/auth/me")
def me(user: User = Depends(get_current_user)):
    return _user_out(user)


@router.get("/profile")
def get_profile(user: User = Depends(get_current_user)):
    p = user.profile
    return {"target_role": p.target_role, "education": p.education, "experience": p.experience, "skills": p.skills, "goals": p.goals}


@router.put("/profile")
def put_profile(body: ProfileIO, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = user.profile
    p.target_role, p.education, p.experience = body.target_role, body.education, body.experience
    p.skills, p.goals = [s.strip() for s in body.skills if s.strip()][:50], body.goals
    db.commit()
    return get_profile(user)
