import os
import tempfile
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import audit, get_current_user
from ..models import (CandidateAnswer, EvaluationResult, InterviewQuestion, InterviewSession, ModelVersion, Resume,
                      User, UserFeedback)
from ..schemas import AnswerIn, FeedbackIn, InterviewCreate, ReEvalIn
from ..services import adaptive, analytics, evaluator
from ..services.resume_parser import find_skills

router = APIRouter(tags=["interviews"])
AUDIO_TYPES = {"audio/webm", "audio/wav", "audio/x-wav", "audio/mpeg", "audio/ogg", "audio/mp4", "video/webm"}


def _own_session(db: Session, user: User, sid: str) -> InterviewSession:
    s = db.get(InterviewSession, sid)
    if not s or s.user_id != user.id:
        raise HTTPException(404, "Interview not found")
    return s


def _public_q(q: InterviewQuestion) -> dict:
    return {"id": q.id, "order_index": q.order_index, "text": q.text, "type": q.qtype, "competency": q.competency,
            "difficulty": q.difficulty, "time_limit_sec": q.time_limit_sec, "is_followup": q.is_followup}


def _eval_out(e: EvaluationResult) -> dict:
    return {"overall": e.overall, "components": e.components, "details": e.details, "feedback": e.feedback,
            "model_version": e.model_version, "rubric_version": e.rubric_version}


def _model_version(db: Session, name: str, rubric: str) -> None:
    if not db.query(ModelVersion).filter_by(name=name, rubric_version=rubric).first():
        db.add(ModelVersion(name=name, rubric_version=rubric, notes="Rubric features + embedding similarity (unvalidated weights)"))
        db.commit()


def _resume_skills(db: Session, s: InterviewSession) -> list[str]:
    if not s.resume_id:
        return []
    r = db.get(Resume, s.resume_id)
    return r.analysis.get("skills", []) if r and r.user_id == s.user_id else []


def _asked_state(s: InterviewSession) -> list[dict]:
    out = []
    for q in s.questions:
        ev = q.answer.evaluation if q.answer and q.answer.evaluation else None
        out.append({"id": q.id, "bank_id": q.bank_id, "competency": q.competency, "qtype": q.qtype, "difficulty": q.difficulty,
                    "is_followup": q.is_followup, "parent_id": q.parent_id, "overall": ev.overall if ev else None,
                    "completeness": ev.components.get("completeness", 100) if ev else None,
                    "missing": ev.feedback.get("missing", []) if ev else [],
                    "followups": q.rubric.get("followups", {}), "concepts": q.rubric["concepts"], "reference": q.rubric["reference"]})
    return out


def _next_question(db: Session, s: InterviewSession) -> dict:
    if s.started_at:
        started = s.started_at if s.started_at.tzinfo else s.started_at.replace(tzinfo=timezone.utc)
        if (datetime.now(timezone.utc) - started).total_seconds() > s.config["duration_minutes"] * 60:
            return {"done": True, "reason": "time limit reached"}
    qd, reason = adaptive.pick_next(s.config, _asked_state(s), _resume_skills(db, s))
    if qd is None:
        return {"done": True, "reason": reason}
    q = InterviewQuestion(
        session_id=s.id, bank_id=qd["id"], order_index=len(s.questions), text=qd["text"], qtype=qd["type"],
        competency=qd["competency"], difficulty=qd["difficulty"], time_limit_sec=qd.get("time", 150),
        rubric={"concepts": qd["concepts"], "misconceptions": qd.get("misconceptions", []), "reference": qd["reference"], "followups": qd.get("followups", {})},
        is_followup="_followup_of" in qd, parent_id=qd.get("_followup_of"))
    db.add(q)
    db.commit()
    s.questions.append(q)
    return {"done": False, "question": _public_q(q), "policy_reason": reason}


def _run_eval(q: InterviewQuestion, text: str, skipped: bool) -> dict:
    return evaluator.evaluate({"text": q.text, "qtype": q.qtype, "rubric": q.rubric}, text, skipped)


@router.post("/interviews", status_code=201)
def create_interview(body: InterviewCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    skills = [x.strip() for x in body.skills if x.strip()][:20]
    if body.resume_id:
        r = db.get(Resume, body.resume_id)
        if not r or r.user_id != user.id:
            raise HTTPException(404, "Resume not found")
    if body.job_description:
        skills = list(dict.fromkeys(skills + find_skills(body.job_description)))
    has_projects = bool(body.resume_id)
    plan = adaptive.build_plan(body.interview_type, body.num_questions, has_projects)
    cfg = body.model_dump(exclude={"job_description"})
    cfg.update(skills=skills, plan=plan, has_job_description=bool(body.job_description))
    s = InterviewSession(user_id=user.id, resume_id=body.resume_id, config=cfg)
    db.add(s)
    db.commit()
    audit(db, user.id, "interview_create", s.id)
    return {"id": s.id, "status": s.status, "plan": [{"slot": i + 1, "type": t} for i, t in enumerate(plan)], "config": cfg}


@router.get("/interviews")
def list_interviews(skip: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=50),
                    user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(InterviewSession).filter_by(user_id=user.id)
    total = q.count()
    items = q.order_by(InterviewSession.created_at.desc()).offset(skip).limit(limit).all()
    return {"total": total, "items": [{"id": s.id, "status": s.status, "role": s.config["role"], "type": s.config["interview_type"],
                                       "created_at": s.created_at.isoformat(), "overall": s.summary.get("overall")} for s in items]}


@router.get("/interviews/{interview_id}")
def get_interview(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    return {"id": s.id, "status": s.status, "config": s.config, "questions": [{**_public_q(q), "answered": q.answer is not None} for q in s.questions], "summary": s.summary}


@router.delete("/interviews/{interview_id}", status_code=204)
def delete_interview(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    db.delete(s)
    db.commit()
    audit(db, user.id, "interview_delete", interview_id)


@router.post("/interviews/{interview_id}/start")
def start(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    if s.status != "created":
        raise HTTPException(409, "Interview already started")
    s.status, s.started_at = "in_progress", datetime.now(timezone.utc)
    db.commit()
    return _next_question(db, s)


@router.post("/interviews/{interview_id}/transcribe")
async def transcribe(interview_id: str, consent: bool = Form(...), audio: UploadFile = File(...),
                     user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Speech-to-text. Audio is processed transiently and deleted; only the (editable) transcript is kept."""
    _own_session(db, user, interview_id)
    if not consent:
        raise HTTPException(400, "Recording consent is required")
    if (audio.content_type or "").split(";")[0] not in AUDIO_TYPES:
        raise HTTPException(415, "Unsupported audio type")
    data = await audio.read(10 * 1024 * 1024 + 1)
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, "Audio larger than 10 MB")
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise HTTPException(501, "Speech recognition not installed (pip install faster-whisper). Type your answer instead.")
    global _WHISPER
    if "_WHISPER" not in globals():
        _WHISPER = WhisperModel(settings.whisper_model, compute_type="int8")
    fd, tmp = tempfile.mkstemp(suffix=".webm")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        segs, info = _WHISPER.transcribe(tmp, vad_filter=True)
        segs = list(segs)
    finally:
        os.remove(tmp)
    import math
    probs = [math.exp(s.avg_logprob) for s in segs if getattr(s, "avg_logprob", None) is not None]
    return {"text": " ".join(s.text.strip() for s in segs), "language": info.language,
            "segments": [{"start": s.start, "end": s.end, "text": s.text} for s in segs],
            "asr_confidence": sum(probs) / len(probs) if probs else None,
            "note": "Review and correct the transcript before submitting."}


@router.post("/interviews/{interview_id}/answers", status_code=201)
def submit_answer(interview_id: str, body: AnswerIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    if s.status != "in_progress":
        raise HTTPException(409, "Interview is not in progress")
    q = db.get(InterviewQuestion, body.question_id)
    if not q or q.session_id != s.id:
        raise HTTPException(404, "Question not found in this interview")
    if q.answer:
        raise HTTPException(409, "Question already answered")
    text = body.text.strip()
    result = _run_eval(q, text, body.skipped)
    a = CandidateAnswer(question_id=q.id, user_id=user.id, text=text, original_transcript=body.original_transcript,
                        via_voice=body.via_voice, skipped=body.skipped or not text, duration_sec=body.duration_sec,
                        speech_metrics=evaluator.speech_metrics(text, body.duration_sec, body.speech_segments, body.asr_confidence)
                        if (body.via_voice or body.duration_sec) else {})
    db.add(a)
    db.flush()
    db.add(EvaluationResult(answer_id=a.id, **result))
    db.commit()
    _model_version(db, result["model_version"], result["rubric_version"])
    return {"answer_id": a.id, "evaluation": result, "speech_metrics": a.speech_metrics}


@router.post("/interviews/{interview_id}/next-question")
def next_question(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    if s.status != "in_progress":
        raise HTTPException(409, "Interview is not in progress")
    if s.questions and not s.questions[-1].answer:
        raise HTTPException(409, "Answer or skip the current question first")
    return _next_question(db, s)


@router.post("/interviews/{interview_id}/complete")
def complete(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    if s.status == "completed":
        return {"id": s.id, "summary": s.summary}
    s.completed_at = datetime.now(timezone.utc)
    s.status = "completed"
    rows = analytics.session_rows(db, user.id, s.id)
    s.summary = analytics.summarize(rows)
    if s.started_at:
        st = s.started_at if s.started_at.tzinfo else s.started_at.replace(tzinfo=timezone.utc)
        s.summary["duration_sec"] = int((s.completed_at - st).total_seconds())
    s.summary["unanswered_questions"] = len(s.questions) - len(rows)
    db.commit()
    audit(db, user.id, "interview_complete", s.id)
    return {"id": s.id, "summary": s.summary}


@router.get("/interviews/{interview_id}/results")
def results(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own_session(db, user, interview_id)
    rows = analytics.session_rows(db, user.id, s.id)
    summary = s.summary or analytics.summarize(rows)
    items = [{**_public_q(q), "answer_id": a.id, "answer": a.text, "skipped": a.skipped, "duration_sec": a.duration_sec,
              "speech_metrics": a.speech_metrics, "evaluation": _eval_out(e)} for q, a, e in rows]
    answered_ids = {i["id"] for i in items}
    unanswered = [_public_q(q) for q in s.questions if q.id not in answered_ids]
    return {"id": s.id, "status": s.status, "config": s.config, "summary": summary, "items": items, "unanswered": unanswered,
            "disclaimer": "Practice scores are model-based estimates, not guarantees of interview outcomes."}


def _own_answer(db: Session, user: User, aid: str) -> CandidateAnswer:
    a = db.get(CandidateAnswer, aid)
    if not a or a.user_id != user.id:
        raise HTTPException(404, "Answer not found")
    return a


@router.post("/answers/{answer_id}/evaluate")
def re_evaluate(answer_id: str, body: ReEvalIn | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Re-run evaluation, optionally with a corrected transcript."""
    a = _own_answer(db, user, answer_id)
    if body and body.text.strip():
        a.original_transcript = a.original_transcript or a.text
        a.text, a.skipped = body.text.strip(), False
    r = _run_eval(a.question, a.text, a.skipped)
    e = a.evaluation
    e.overall, e.components, e.details, e.feedback = r["overall"], r["components"], r["details"], r["feedback"]
    e.model_version, e.rubric_version = r["model_version"], r["rubric_version"]
    db.commit()
    return _eval_out(e)


@router.post("/answers/{answer_id}/feedback", status_code=201)
def flag(answer_id: str, body: FeedbackIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = _own_answer(db, user, answer_id)
    db.add(UserFeedback(user_id=user.id, answer_id=a.id, kind=body.kind, comment=body.comment))
    db.commit()
    return {"status": "recorded"}
