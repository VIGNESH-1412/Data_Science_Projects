from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import audit, get_current_user
from ..models import GeneratedReport, InterviewSession, User
from ..services import analytics, report

router = APIRouter(tags=["analytics"])


@router.get("/analytics/performance")
def performance(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    prog = analytics.progress(db, user.id)
    comparison = None
    if len(prog) >= 2:
        a, b = prog[-2], prog[-1]
        comparison = {"previous": a["overall"], "current": b["overall"], "change": round((b["overall"] or 0) - (a["overall"] or 0), 1)}
    return {"sessions": prog, "comparison": comparison, "disclaimer": "Model-based practice estimates."}


@router.get("/analytics/skill-gaps")
def skill_gaps(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return analytics.skill_gaps(db, user.id)


@router.post("/interviews/{interview_id}/report", status_code=201)
def make_report(interview_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = db.get(InterviewSession, interview_id)
    if not s or s.user_id != user.id:
        raise HTTPException(404, "Interview not found")
    if s.status != "completed":
        raise HTTPException(409, "Complete the interview first")
    rows = analytics.session_rows(db, user.id, s.id)
    path = str(Path(settings.upload_dir) / "reports" / user.id / f"{s.id}.pdf")
    report.build_pdf(path, s, s.summary, rows, analytics.skill_gaps(db, user.id)["learning_plan"], user.full_name)
    r = GeneratedReport(user_id=user.id, session_id=s.id, path=path)
    db.add(r)
    db.commit()
    audit(db, user.id, "report_generate", r.id)
    return {"id": r.id, "download": f"/api/v1/reports/{r.id}"}


@router.get("/reports/{report_id}")
def get_report(report_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.get(GeneratedReport, report_id)
    if not r or r.user_id != user.id or not Path(r.path).exists():
        raise HTTPException(404, "Report not found")
    return FileResponse(r.path, media_type="application/pdf", filename="interview-report.pdf")
