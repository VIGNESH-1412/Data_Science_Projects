import os
import uuid
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..deps import audit, get_current_user
from ..models import Resume, User
from ..services import resume_parser as rp

router = APIRouter(tags=["resumes"])
MAGIC = {".pdf": b"%PDF", ".docx": b"PK"}


def _out(r: Resume) -> dict:
    return {"id": r.id, "filename": r.filename, "created_at": r.created_at.isoformat(), "analysis": r.analysis}


def _own(db: Session, user: User, rid: str) -> Resume:
    r = db.get(Resume, rid)
    if not r or r.user_id != user.id:
        raise HTTPException(404, "Resume not found")
    return r


@router.post("/resumes", status_code=201)
async def upload(file: UploadFile = File(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in MAGIC:
        raise HTTPException(415, "Only PDF and DOCX files are accepted")
    data = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"File larger than {settings.max_upload_mb} MB")
    if not data.startswith(MAGIC[ext]):
        raise HTTPException(415, "File content does not match its extension")
    folder = Path(settings.upload_dir) / "resumes" / user.id
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{uuid.uuid4()}{ext}"
    path.write_bytes(data)
    try:
        analysis = rp.analyze(rp.extract_text(str(path), file.filename))
    except Exception:
        path.unlink(missing_ok=True)
        raise HTTPException(422, "Could not read text from this file")
    r = Resume(user_id=user.id, filename=Path(file.filename).name[:255], stored_path=str(path), analysis=analysis)
    db.add(r)
    db.commit()
    audit(db, user.id, "resume_upload", r.id)
    return _out(r)


@router.get("/resumes")
def list_resumes(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return [_out(r) for r in db.query(Resume).filter_by(user_id=user.id).order_by(Resume.created_at.desc()).all()]


@router.delete("/resumes/{resume_id}", status_code=204)
def delete_resume(resume_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = _own(db, user, resume_id)
    try:
        os.remove(r.stored_path)
    except FileNotFoundError:
        pass
    db.delete(r)
    db.commit()
    audit(db, user.id, "resume_delete", resume_id)


@router.post("/resumes/{resume_id}/compatibility")
def compat(resume_id: str, job_description: str = Body(..., embed=True, max_length=8000),
           user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = _own(db, user, resume_id)
    return rp.compatibility(r.analysis.get("skills", []), job_description)
