"""Average annotator ratings per answer and make leakage-safe splits.
Near-duplicate answers (TF-IDF cosine >= 0.85) are grouped and kept in the same split."""
import sys
import pandas as pd
from scipy.sparse.csgraph import connected_components
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import GroupShuffleSplit

SRC, OUT = "data/annotated_answers.csv", "data/splits.csv"
DIMS = ["relevance", "correctness", "completeness", "communication"]


def main():
    try:
        df = pd.read_csv(SRC)
    except FileNotFoundError:
        sys.exit(f"{SRC} not found. Create it from data/annotated_answers.template.csv (see data/DATASETS.md).")
    g = df.groupby(["question_id", "answer"])
    agg = g[DIMS].mean().reset_index()
    for d in DIMS:  # disagreement = std across annotators
        agg[d + "_std"] = g[d].std().fillna(0).values
    X = TfidfVectorizer().fit_transform(agg["answer"])
    sim = (X @ X.T) >= 0.85
    _, agg["group"] = connected_components(sim, directed=False)
    gss1 = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    trainval, test = next(gss1.split(agg, groups=agg["group"]))
    gss2 = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    sub = agg.iloc[trainval]
    tr, va = next(gss2.split(sub, groups=sub["group"]))
    agg["split"] = "train"
    agg.loc[sub.index[va], "split"] = "val"
    agg.loc[agg.index[test], "split"] = "test"
    agg.to_csv(OUT, index=False)
    print(agg["split"].value_counts().to_string())


if __name__ == "__main__":
    main()
