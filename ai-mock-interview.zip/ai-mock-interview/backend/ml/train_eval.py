"""Compare two approaches against human ratings on a held-out test split.
  A) baseline: rubric/handcrafted features + GradientBoosting (scikit-learn pipeline)
  B) advanced: Sentence-Transformer embedding features (answer, answer*reference) + Ridge
Only trained on `train`, tuned on `val`, reported on `test`. Prints what it measures; invents nothing.
Run: python -m ml.prepare_splits && python -m ml.train_eval"""
import json
import sys

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from app.services import evaluator
from app.services.question_bank import BANK

TARGET = "correctness"  # change to relevance / completeness / communication
BYID = {b["id"]: b for b in BANK}


def rubric_features(row) -> list[float]:
    b = BYID[row.question_id]
    cov = evaluator.concept_coverage(row.answer, b["concepts"])
    comm, f = evaluator.communication_quality(row.answer)
    miscs = evaluator.find_misconceptions(row.answer, b["misconceptions"])
    return [evaluator.completeness_from(cov), evaluator.semantic_relevance(b["text"], b["reference"], row.answer), comm,
            f.get("word_count", 0), f.get("filler_count", 0), len(miscs)]


def embed_features(df) -> np.ndarray:
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    a = m.encode(df["answer"].tolist(), normalize_embeddings=True)
    r = m.encode([BYID[q]["reference"] for q in df["question_id"]], normalize_embeddings=True)
    return np.hstack([a, a * r, (a * r).sum(1, keepdims=True)])


def report(name, y, p, df):
    y, p = np.asarray(y), np.asarray(p)
    out = {"model": name, "MAE": float(mean_absolute_error(y, p)), "RMSE": float(np.sqrt(((y - p) ** 2).mean())),
           "spearman": float(spearmanr(y, p).correlation)}
    out["by_question_type"] = {t: float(mean_absolute_error(y[m], p[m])) for t in df["qtype"].unique() if (m := (df["qtype"] == t).values).sum() > 1}
    long = df["answer"].str.split().str.len() > df["answer"].str.split().str.len().median()
    out["MAE_long_answers"], out["MAE_short_answers"] = float(mean_absolute_error(y[long], p[long])), float(mean_absolute_error(y[~long], p[~long]))
    return out


def main():
    try:
        df = pd.read_csv("data/splits.csv")
    except FileNotFoundError:
        sys.exit("data/splits.csv missing. Run `python -m ml.prepare_splits` after creating data/annotated_answers.csv")
    df["qtype"] = df["question_id"].map(lambda q: BYID[q]["type"])
    tr, va, te = (df[df.split == s] for s in ("train", "val", "test"))
    if min(len(tr), len(va), len(te)) < 10:
        print("WARNING: very small splits; metrics will be unstable. Annotate more answers.")
    y = lambda d: d[TARGET].values
    results = []

    Xb = {k: np.array([rubric_features(r) for r in d.itertuples()]) for k, d in (("tr", tr), ("va", va), ("te", te))}
    best = None
    for depth in (2, 3):  # tune on validation only
        mdl = make_pipeline(StandardScaler(), GradientBoostingRegressor(max_depth=depth, n_estimators=150, random_state=0)).fit(Xb["tr"], y(tr))
        mae = mean_absolute_error(y(va), mdl.predict(Xb["va"]))
        best = (mae, mdl) if best is None or mae < best[0] else best
    results.append(report("baseline_rubric_features_gbr", y(te), best[1].predict(Xb["te"]), te))

    Xe = {k: embed_features(d) for k, d in (("tr", tr), ("va", va), ("te", te))}
    best = None
    for alpha in (0.1, 1, 10):
        mdl = Ridge(alpha=alpha).fit(Xe["tr"], y(tr))
        mae = mean_absolute_error(y(va), mdl.predict(Xe["va"]))
        best = (mae, mdl) if best is None or mae < best[0] else best
    results.append(report("embedding_ridge", y(te), best[1].predict(Xe["te"]), te))

    # How does the shipped heuristic scorer (no training) correlate with humans?
    heur = [evaluator.completeness_from(evaluator.concept_coverage(r.answer, BYID[r.question_id]["concepts"])) for r in te.itertuples()]
    results.append({"model": "shipped_heuristic_completeness_vs_human_" + TARGET, "spearman": float(spearmanr(y(te), heur).correlation)})
    json.dump(results, open("ml/results.json", "w"), indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
