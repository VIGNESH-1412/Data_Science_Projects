# Datasets and annotation plan

No trained-model results are shipped with this project. Fill the table below with what you actually use.

| Resource | Source | License | Intended use here | Limitations |
|---|---|---|---|---|
| STS Benchmark | ixa2.si.ehu.eus/stswiki / HF `mteb/stsbenchmark-sts` | check the dataset card | Sanity-check the embedding model's semantic similarity (Spearman) | General sentences, not interview answers |
| SQuAD 2.0 | rajpurkar.github.io/SQuAD-explorer | CC BY-SA 4.0 | Optional QA baseline experiments | Reading comprehension, not interview scoring |
| Your annotated answers | collected with participant consent | your choice | Train/validate/test the scorer | Small N; annotator subjectivity |

## Annotation protocol (suggested)
1. Collect 15-30 answers for each of ~20 questions from consenting volunteers (classmates). Remove names/PII.
2. Two or more annotators rate relevance, correctness, completeness, communication on a 1-5 scale using the rubric in `question_bank.py` (do not look at model scores while rating).
3. Save as `data/annotated_answers.csv` using `annotated_answers.template.csv` as the header. One row per (answer, annotator).
4. Report inter-annotator agreement (Cohen's weighted kappa / Spearman) before training.
